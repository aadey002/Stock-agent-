// ============================================================
// Q5D DASHBOARD FIXES
// Paste these fixes into your index.html <script> section
// ============================================================

// ISSUE FIX 1: Options Calculator Auto-Populate Current Price
// ============================================================
// Replace or add this function to auto-populate stock price when symbol changes

function updateOptionsCalcPrice() {
    // Get current symbol price from header or data
    const priceElement = document.querySelector('.price-value');
    const stockPriceInput = document.getElementById('stockPrice') || 
                            document.querySelector('input[name="stockPrice"]') ||
                            document.querySelector('#optionsCalc input[type="number"]:first-of-type');
    
    if (priceElement && stockPriceInput) {
        const priceText = priceElement.textContent || priceElement.innerText;
        const price = parseFloat(priceText.replace(/[$,]/g, ''));
        
        if (!isNaN(price) && price > 0) {
            stockPriceInput.value = price.toFixed(2);
            console.log(`[Options Calc] Updated price to: $${price.toFixed(2)}`);
        }
    }
}

// ISSUE FIX 2: Multi-Charts Symbol Sync
// ============================================================
// This ensures charts update when symbol dropdown changes

function syncChartsWithSymbol() {
    // Get current symbol from dropdown
    const symbolDropdown = document.getElementById('symbolSelect') || 
                           document.querySelector('select[name="symbol"]');
    
    if (!symbolDropdown) {
        console.warn('[Charts] Symbol dropdown not found');
        return;
    }
    
    const symbol = symbolDropdown.value;
    
    // Update all chart headers with correct symbol
    const chartHeaders = document.querySelectorAll('.chart-header, .chart-title, .chart-symbol');
    chartHeaders.forEach(header => {
        if (header.textContent.includes('SPY') && symbol !== 'SPY') {
            header.textContent = header.textContent.replace('SPY', symbol);
        }
    });
    
    // Update chart data source
    if (typeof loadChartData === 'function') {
        loadChartData(symbol);
    }
    
    console.log(`[Charts] Synced to symbol: ${symbol}`);
}

// ISSUE FIX 3: Market Status Detection
// ============================================================
// Properly detect market hours

function getMarketStatus() {
    const now = new Date();
    const day = now.getDay();
    
    // Weekend check
    if (day === 0 || day === 6) {
        return { status: 'CLOSED', label: 'Weekend - CLOSED', color: 'gray' };
    }
    
    // Convert to ET
    const etOffset = -5; // EST (change to -4 for EDT if needed)
    const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
    const et = new Date(utc + (3600000 * etOffset));
    
    const hours = et.getHours();
    const minutes = et.getMinutes();
    const timeValue = hours * 100 + minutes;
    
    // Pre-market: 4:00 AM - 9:30 AM ET
    if (timeValue >= 400 && timeValue < 930) {
        return { status: 'PRE', label: 'Pre-Market', color: 'yellow' };
    }
    
    // Regular hours: 9:30 AM - 4:00 PM ET
    if (timeValue >= 930 && timeValue < 1600) {
        return { status: 'OPEN', label: 'Market Open', color: 'green' };
    }
    
    // After hours: 4:00 PM - 8:00 PM ET
    if (timeValue >= 1600 && timeValue < 2000) {
        return { status: 'AFTER', label: 'After Hours', color: 'orange' };
    }
    
    // Closed
    return { status: 'CLOSED', label: 'Market Closed', color: 'gray' };
}

function updateMarketStatus() {
    const status = getMarketStatus();
    
    // Find market status element
    const statusElement = document.getElementById('marketStatus') ||
                          document.querySelector('.market-status') ||
                          document.querySelector('[data-market-status]');
    
    if (statusElement) {
        statusElement.textContent = status.label;
        statusElement.className = `market-status status-${status.status.toLowerCase()}`;
        statusElement.style.color = status.color === 'green' ? '#22c55e' :
                                    status.color === 'yellow' ? '#eab308' :
                                    status.color === 'orange' ? '#f97316' : '#6b7280';
    }
    
    console.log(`[Market] Status: ${status.label}`);
}

// ISSUE FIX 4: Symbol Change Handler
// ============================================================
// Master handler for symbol dropdown changes

function handleSymbolChange(newSymbol) {
    console.log(`[Symbol] Changed to: ${newSymbol}`);
    
    // Update current symbol variable
    if (typeof currentSymbol !== 'undefined') {
        currentSymbol = newSymbol;
    }
    
    // Load new symbol data
    if (typeof loadSymbolData === 'function') {
        loadSymbolData(newSymbol);
    }
    
    // Update Options Calculator price
    setTimeout(updateOptionsCalcPrice, 500);
    
    // Sync Multi-Charts
    syncChartsWithSymbol();
    
    // Refresh all displays
    if (typeof refreshDashboard === 'function') {
        refreshDashboard();
    }
}

// ISSUE FIX 5: Data Freshness Check
// ============================================================
// Check if data is current

function checkDataFreshness() {
    // Try to get last date from SPY data
    if (typeof currentData !== 'undefined' && currentData.length > 0) {
        const lastBar = currentData[currentData.length - 1];
        const lastDate = new Date(lastBar.Date || lastBar.date);
        const now = new Date();
        
        // Calculate days difference
        const diffTime = Math.abs(now - lastDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        const freshnessElement = document.getElementById('dataFreshness') ||
                                  document.querySelector('.data-freshness');
        
        if (freshnessElement) {
            if (diffDays <= 1) {
                freshnessElement.textContent = 'Current';
                freshnessElement.style.color = '#22c55e';
            } else if (diffDays <= 3) {
                freshnessElement.textContent = `${diffDays} Days Old`;
                freshnessElement.style.color = '#eab308';
            } else {
                freshnessElement.textContent = `${diffDays} Days Old`;
                freshnessElement.style.color = '#ef4444';
            }
        }
        
        return { days: diffDays, lastDate: lastDate };
    }
    
    return { days: -1, lastDate: null };
}

// ISSUE FIX 6: Load Market Conditions for Guard Rail
// ============================================================

async function loadMarketConditions() {
    try {
        const response = await fetch('data/market_conditions.json');
        if (!response.ok) {
            throw new Error('Market conditions not found');
        }
        
        const conditions = await response.json();
        
        // Update VIX display
        const vixElement = document.getElementById('vixLevel') ||
                           document.querySelector('.vix-level');
        if (vixElement) {
            vixElement.textContent = conditions.vix_level || '--';
            
            const vixStatus = document.querySelector('.vix-status');
            if (vixStatus) {
                vixStatus.textContent = conditions.vix_status || '';
            }
        }
        
        // Update SPY Trend
        const trendElement = document.getElementById('spyTrend') ||
                             document.querySelector('.spy-trend');
        if (trendElement) {
            trendElement.textContent = conditions.spy_trend || '--';
            
            const trendPct = document.querySelector('.trend-pct');
            if (trendPct) {
                const pct = conditions.spy_trend_pct || 0;
                trendPct.textContent = `${pct >= 0 ? '+' : ''}${pct}% from MA`;
            }
        }
        
        // Update Sector Rotation
        const rotationElement = document.getElementById('sectorRotation') ||
                                document.querySelector('.sector-rotation');
        if (rotationElement) {
            rotationElement.textContent = conditions.sector_rotation || '--';
            
            const rotationDesc = document.querySelector('.rotation-desc');
            if (rotationDesc) {
                rotationDesc.textContent = conditions.sector_rotation_desc || '';
            }
        }
        
        // Update Trade Conditions
        const conditionsElement = document.getElementById('tradeConditions') ||
                                  document.querySelector('.trade-conditions');
        if (conditionsElement) {
            conditionsElement.textContent = conditions.trade_conditions || '--';
        }
        
        // Update Safe to Trade indicator
        const safeElement = document.getElementById('safeToTrade') ||
                            document.querySelector('.safe-to-trade');
        if (safeElement) {
            if (conditions.safe_to_trade) {
                safeElement.innerHTML = '🟢 SAFE TO TRADE';
                safeElement.className = 'safe-to-trade safe';
            } else {
                safeElement.innerHTML = '🔴 CAUTION';
                safeElement.className = 'safe-to-trade caution';
            }
        }
        
        console.log('[Guard Rail] Market conditions loaded:', conditions);
        return conditions;
        
    } catch (error) {
        console.error('[Guard Rail] Error loading market conditions:', error);
        return null;
    }
}

// ============================================================
// INITIALIZATION
// ============================================================

// Add event listener for symbol dropdown
document.addEventListener('DOMContentLoaded', function() {
    // Find symbol dropdown and attach listener
    const symbolDropdown = document.getElementById('symbolSelect') ||
                           document.querySelector('select[name="symbol"]') ||
                           document.querySelector('.symbol-dropdown select');
    
    if (symbolDropdown) {
        symbolDropdown.addEventListener('change', function(e) {
            handleSymbolChange(e.target.value);
        });
    }
    
    // Initial updates
    updateMarketStatus();
    checkDataFreshness();
    loadMarketConditions();
    
    // Update market status every minute
    setInterval(updateMarketStatus, 60000);
    
    // Update data freshness every 5 minutes
    setInterval(checkDataFreshness, 300000);
    
    console.log('[Dashboard] Fixes initialized');
});

// ============================================================
// EXPORT FOR USE IN GLOBAL SCOPE
// ============================================================

window.updateOptionsCalcPrice = updateOptionsCalcPrice;
window.syncChartsWithSymbol = syncChartsWithSymbol;
window.getMarketStatus = getMarketStatus;
window.updateMarketStatus = updateMarketStatus;
window.handleSymbolChange = handleSymbolChange;
window.checkDataFreshness = checkDataFreshness;
window.loadMarketConditions = loadMarketConditions;
