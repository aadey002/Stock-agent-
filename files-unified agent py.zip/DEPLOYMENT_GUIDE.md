# 🚀 STOCK AGENT 4 - COMPLETE UPDATE GUIDE

## 📋 Issues Fixed by This Update

| # | Issue | Screenshot | Solution |
|---|-------|------------|----------|
| 1 | **Missing 12/1/25 Data** | playbook_comparison.csv | New unified_agent.py generates daily |
| 2 | **Missing Ultra Signals** | ultra_confluence_4of4.csv | New agent creates 4/4 consensus signals |
| 3 | **Wrong Symbol in Charts** | Multi-Charts shows SPY for XLE | dashboard_fixes.js syncs charts |
| 4 | **Options Calc Price Wrong** | Shows $600 not $91.32 | Auto-populate function added |
| 5 | **Market Status Detection** | Pre-Market always showing | getMarketStatus() function |
| 6 | **Guard Rail Data Missing** | No VIX, no rotation data | market_conditions.json generated |

---

## 📁 FILES TO DEPLOY

| File | Purpose | Deploy To |
|------|---------|-----------|
| `unified_agent.py` | Complete multi-symbol agent with all 4 trading agents | Repository root |
| `confluence_agent.yml` | GitHub Actions workflow | `.github/workflows/` |
| `dashboard_fixes.js` | JavaScript fixes for Options Calc, Charts, Market Status | Paste into index.html |

---

## 📝 STEP-BY-STEP DEPLOYMENT

### STEP 1: Upload `unified_agent.py`

**Using GitHub Web Interface:**

1. Go to: https://github.com/aadey002/Stock-agent-
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop `unified_agent.py`
4. Commit message: `Add unified multi-agent trading system`
5. Click **"Commit changes"**

**Using PowerShell:**
```powershell
cd C:\Users\adeto\Documents\Stock-agent-
# Copy unified_agent.py to your repo folder first, then:
git add unified_agent.py
git commit -m "Add unified multi-agent trading system"
git push origin main
```

---

### STEP 2: Update GitHub Actions Workflow

**Replace the workflow file:**

1. Go to: https://github.com/aadey002/Stock-agent-/edit/main/.github/workflows/confluence_agent.yml
2. **Ctrl+A** to select all
3. **Delete** all content
4. Open `confluence_agent.yml` from downloads
5. **Ctrl+A** → **Ctrl+C** to copy all
6. **Ctrl+V** to paste into GitHub
7. Click **"Commit changes"**

---

### STEP 3: Add Dashboard Fixes to index.html

**Find your index.html and add the JavaScript fixes:**

1. Go to: https://github.com/aadey002/Stock-agent-/edit/gh-pages/index.html
   (or edit in main branch if that's where your dashboard is)

2. Find the closing `</body>` tag

3. Add this **BEFORE** `</body>`:

```html
<script>
// === Q5D DASHBOARD FIXES ===
// Paste the entire contents of dashboard_fixes.js here
</script>
```

4. Click **"Commit changes"**

---

### STEP 4: Run the Workflow

1. Go to: https://github.com/aadey002/Stock-agent-/actions
2. Click **"Q5D Daily Analysis"** (or "Confluence Agent")
3. Click **"Run workflow"** button
4. Select **"main"** branch
5. Click **"Run workflow"**
6. Wait for ✅ green checkmark

---

### STEP 5: Verify Dashboard

1. Go to: https://aadey002.github.io/Stock-agent-/
2. Press **Ctrl+Shift+R** (hard refresh)
3. Check each fix:

| Feature | What to Check |
|---------|---------------|
| **Playbook Comparison** | Should show today's date |
| **Ultra Confluence** | Should show recent signals |
| **Multi-Charts** | Should update when you change symbol |
| **Options Calc** | Should auto-fill current price |
| **Health Tab** | Market status should be accurate |
| **Guard Rail** | VIX, SPY Trend, Rotation should show data |

---

## 📊 OUTPUT FILES GENERATED

The unified_agent.py generates these files:

### Data Files (in `data/` folder):
- `SPY.csv` - S&P 500 OHLCV with indicators
- `QQQ.csv` - NASDAQ 100
- `IWM.csv` - Russell 2000
- `XLE.csv` - Energy sector
- `XLF.csv` - Financials
- `XLK.csv` - Technology
- `XLV.csv` - Healthcare
- `XLI.csv` - Industrials
- `XLB.csv` - Materials
- `XLU.csv` - Utilities
- `XLP.csv` - Consumer Staples
- `XLY.csv` - Consumer Discretionary

### Report Files (in `reports/` folder):
- `playbook_comparison.csv` - All 4 agents comparison (for Reports tab)
- `ultra_confluence_4of4.csv` - 4/4 consensus signals (for Reports tab)
- `super_confluence_signals.csv` - 3/4+ signals
- `portfolio_confluence.csv` - Active trades
- `sector_rotation.csv` - Sector performance
- `market_conditions.json` - Guard Rail data

---

## 🔧 TROUBLESHOOTING

### Issue: Workflow fails
**Check:**
- Look at workflow logs for error messages
- Ensure `unified_agent.py` is in repository root
- Verify Python dependencies are installing

### Issue: Dashboard still shows old data
**Solution:**
- Hard refresh: **Ctrl+Shift+R**
- Wait 2-3 minutes after workflow completes
- Check that workflow actually succeeded (green ✅)

### Issue: Charts not syncing with symbol
**Solution:**
- Make sure `dashboard_fixes.js` is pasted into index.html
- Check browser console for JavaScript errors
- Verify the symbol dropdown ID matches the script

### Issue: Market conditions not loading
**Solution:**
- Verify `market_conditions.json` exists in `web/data/`
- Check the fetch URL in dashboard_fixes.js
- Look for CORS errors in browser console

---

## 📅 SCHEDULE

The workflow runs automatically:
- **Pre-market:** 9:00 AM ET
- **Market hours:** Every 30 minutes 9:30 AM - 4:00 PM ET
- **After close:** 4:30 PM ET

You can also run manually anytime via **"Run workflow"** button.

---

## ✅ CHECKLIST

- [ ] Downloaded `unified_agent.py`
- [ ] Downloaded `confluence_agent.yml`
- [ ] Downloaded `dashboard_fixes.js`
- [ ] Uploaded `unified_agent.py` to repo root
- [ ] Replaced workflow in `.github/workflows/`
- [ ] Added JavaScript fixes to index.html
- [ ] Ran workflow manually
- [ ] Verified dashboard shows current data
- [ ] Tested symbol change updates charts
- [ ] Tested Options Calc auto-populates price

---

**Questions?** Check the workflow logs at: https://github.com/aadey002/Stock-agent-/actions
