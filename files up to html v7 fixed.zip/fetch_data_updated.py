# =========================================================================
# UPDATED DATA FETCHING WITH YAHOO BACKUP
# Replace the existing fetch_tiingo_daily_with_retry function with this
# =========================================================================

from datetime import date, datetime, timedelta
import json
import logging
import os
import time
import urllib.request
import urllib.error

MAX_RETRIES = 3
RETRY_DELAY = 2
REQUEST_TIMEOUT = 30

logger = logging.getLogger("confluence_agent")

def fetch_tiingo_daily_with_retry(
    symbol: str, 
    start_date: str,
    max_retries: int = MAX_RETRIES
) -> list:
    """
    Fetch daily OHLCV from Tiingo with Yahoo Finance fallback.
    Explicitly includes endDate=today for latest data.
    """
    # Try Tiingo first
    bars = _fetch_from_tiingo(symbol, start_date, max_retries)
    
    if bars:
        # Check if we have today's data
        last_date = bars[-1].d.split('T')[0] if bars else None
        today = date.today().isoformat()
        
        if last_date == today:
            logger.info(f"✅ Tiingo has today's data ({today})")
            return bars
        else:
            logger.warning(f"⚠️ Tiingo last date is {last_date}, today is {today}")
            logger.info("Trying Yahoo Finance for latest data...")
            
            # Try Yahoo to get latest data
            yahoo_bars = _fetch_from_yahoo(symbol, start_date)
            if yahoo_bars:
                yahoo_last = yahoo_bars[-1].d.split('T')[0] if yahoo_bars else None
                if yahoo_last and yahoo_last > last_date:
                    logger.info(f"✅ Yahoo has newer data ({yahoo_last})")
                    return yahoo_bars
            
            # Return Tiingo data if Yahoo didn't help
            return bars
    
    # Tiingo failed completely, try Yahoo
    logger.warning("Tiingo failed, trying Yahoo Finance...")
    return _fetch_from_yahoo(symbol, start_date)


def _fetch_from_tiingo(symbol: str, start_date: str, max_retries: int) -> list:
    """Fetch from Tiingo API with explicit endDate."""
    token = os.getenv("TIINGO_TOKEN")
    
    if not token:
        logger.error("TIINGO_TOKEN environment variable not set!")
        return []
    
    if len(token) < 20:
        logger.error(f"Invalid TIINGO_TOKEN format (got {len(token)} chars)")
        return []
    
    # FIXED: Include explicit endDate for today
    end_date = date.today().isoformat()
    url = (
        f"https://api.tiingo.com/tiingo/daily/{symbol}/prices"
        f"?startDate={start_date}&endDate={end_date}&token={token}"
    )
    
    bars = []
    
    for attempt in range(1, max_retries + 1):
        try:
            logger.info(f"[Tiingo Attempt {attempt}/{max_retries}] Fetching {symbol}...")
            logger.info(f"Date range: {start_date} to {end_date}")
            
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'ConfluenceAgent/1.0')
            
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
                data = json.loads(response.read().decode('utf-8'))
                
                if not isinstance(data, list):
                    logger.error(f"Unexpected response format: {type(data)}")
                    return []
                
                logger.info(f"Tiingo returned {len(data)} bars for {symbol}")
                
                for item in data:
                    try:
                        bar = Bar(
                            d=item['date'],
                            open_=item['open'],
                            high=item['high'],
                            low=item['low'],
                            close=item['close'],
                            volume=item['volume'],
                        )
                        bars.append(bar)
                    except (KeyError, ValueError) as e:
                        logger.warning(f"Skipped malformed bar: {e}")
                        continue
                
                if bars:
                    logger.info(f"Last Tiingo date: {bars[-1].d.split('T')[0]}")
                
                return bars
        
        except urllib.error.HTTPError as e:
            logger.warning(f"HTTP {e.code}: {e.reason} (attempt {attempt})")
        except urllib.error.URLError as e:
            logger.warning(f"Network error: {e.reason} (attempt {attempt})")
        except Exception as e:
            logger.error(f"Error: {type(e).__name__}: {e}")
        
        if attempt < max_retries:
            wait_time = RETRY_DELAY * (2 ** (attempt - 1))
            logger.info(f"Retrying in {wait_time}s...")
            time.sleep(wait_time)
    
    return []


def _fetch_from_yahoo(symbol: str, start_date: str) -> list:
    """Fetch from Yahoo Finance as backup."""
    try:
        # Calculate timestamps
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        end_dt = datetime.now() + timedelta(days=1)  # Include today
        
        start_ts = int(start_dt.timestamp())
        end_ts = int(end_dt.timestamp())
        
        url = (
            f"https://query1.finance.yahoo.com/v7/finance/download/{symbol}"
            f"?period1={start_ts}&period2={end_ts}&interval=1d&events=history"
        )
        
        logger.info(f"[Yahoo] Fetching {symbol}...")
        
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as response:
            csv_data = response.read().decode('utf-8')
            lines = csv_data.strip().split('\n')
            
            if len(lines) < 2:
                logger.error("Yahoo returned no data")
                return []
            
            bars = []
            for line in lines[1:]:  # Skip header
                try:
                    parts = line.split(',')
                    if len(parts) >= 6 and parts[4] != 'null':
                        bar = Bar(
                            d=parts[0] + "T00:00:00.000Z",
                            open_=float(parts[1]),
                            high=float(parts[2]),
                            low=float(parts[3]),
                            close=float(parts[4]),
                            volume=float(parts[5]) if parts[5] != 'null' else 0,
                        )
                        bars.append(bar)
                except (ValueError, IndexError) as e:
                    continue
            
            logger.info(f"Yahoo returned {len(bars)} bars")
            if bars:
                logger.info(f"Last Yahoo date: {bars[-1].d.split('T')[0]}")
            
            return bars
    
    except Exception as e:
        logger.error(f"Yahoo fetch failed: {type(e).__name__}: {e}")
        return []
