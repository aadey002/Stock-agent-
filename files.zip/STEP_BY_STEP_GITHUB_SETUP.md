# COMPLETE GITHUB SETUP GUIDE - Step by Step

## 🎯 GOAL
Get your backend server running with Tiingo API key safely stored in GitHub Secrets

---

## 📋 CHECKLIST

- [ ] Step 1: Verify TIINGO_API_KEY in GitHub Secrets
- [ ] Step 2: Create `.github/workflows/` folder
- [ ] Step 3: Add backend-server.yml workflow file
- [ ] Step 4: Commit and push to GitHub
- [ ] Step 5: Watch workflow run and test
- [ ] Step 6: Deploy dashboard

---

## STEP 1: Verify TIINGO_API_KEY in GitHub Secrets (2 minutes)

### Option A: Via Web Browser (Easiest)

1. **Open GitHub**
   ```
   https://github.com/aadey002/Stock-agent-/settings/secrets/actions
   ```

2. **Look for `TIINGO_API_KEY`**
   - If it exists → ✅ Great! Skip to Step 2
   - If it doesn't exist → Add it:
     - Click "New repository secret" (green button)
     - Name: `TIINGO_API_KEY`
     - Value: Your Tiingo API key
     - Click "Add secret"

3. **Verify it was added**
   - You should see `TIINGO_API_KEY` in the list
   - It shows as "●●●●●••••••" (hidden for security)

### Option B: Via PowerShell (Advanced)

Run this command:
```powershell
# First, download the script I created
# Then run it:
.\check_github_secrets_local.ps1
```

This will show you all secrets and confirm TIINGO_API_KEY exists.

---

## STEP 2: Create Folder Structure in GitHub (2 minutes)

### Method A: Via Web Browser (Easiest)

1. **Go to your repository**
   ```
   https://github.com/aadey002/Stock-agent-
   ```

2. **Create the folder structure**
   - Click "Add file" → "Create new file"
   - Type in the filename: `.github/workflows/backend-server.yml`
   - GitHub automatically creates folders!

### Method B: Via Git Command Line

If you prefer git (local machine):

```bash
# Clone your repo if you haven't already
git clone https://github.com/aadey002/Stock-agent-.git
cd Stock-agent-

# Create the folder
mkdir -p .github/workflows

# You'll add the file in Step 3
```

---

## STEP 3: Add backend-server.yml File (2 minutes)

### Method A: Via Web Browser (Recommended)

**THIS IS THE EASIEST WAY**

1. **Open GitHub repository**
   ```
   https://github.com/aadey002/Stock-agent-
   ```

2. **Click "Add file" → "Create new file"**

3. **Type the filename path**
   ```
   .github/workflows/backend-server.yml
   ```

4. **Copy and paste the entire code below into the file:**

```yaml
name: Stock Agent Backend Server

on:
  schedule:
    # Run every 15 minutes during market hours (9 AM - 4 PM ET, weekdays)
    - cron: '*/15 9-16 * * 1-5'
  
  workflow_dispatch:  # Allow manual trigger

jobs:
  run-backend:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    
    - name: Cache pip packages
      uses: actions/cache@v3
      with:
        path: ~/.cache/pip
        key: ${{ runner.os }}-pip-${{ hashFiles('**/requirements_server.txt') }}
        restore-keys: |
          ${{ runner.os }}-pip-
    
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install -r requirements_server.txt
    
    - name: Start backend server
      env:
        TIINGO_API_KEY: ${{ secrets.TIINGO_API_KEY }}
        PORT: 5000
      run: |
        # Start server in background
        python server.py > server.log 2>&1 &
        SERVER_PID=$!
        
        # Wait for server to start
        sleep 5
        
        # Check if server is running
        if ! kill -0 $SERVER_PID 2>/dev/null; then
          echo "❌ Server failed to start!"
          cat server.log
          exit 1
        fi
        
        echo "✓ Backend server started (PID: $SERVER_PID)"
    
    - name: Test health endpoint
      run: |
        echo "Testing /api/health..."
        curl -v http://localhost:5000/api/health || true
        echo ""
    
    - name: Test price endpoint (SPY)
      run: |
        echo "Testing /api/price/SPY..."
        curl -v http://localhost:5000/api/price/SPY || true
        echo ""
    
    - name: Test historical endpoint (SPY)
      run: |
        echo "Testing /api/historical/SPY?days=60..."
        curl -v http://localhost:5000/api/historical/SPY?days=60 || true
        echo ""
    
    - name: Test signal endpoint (SPY)
      run: |
        echo "Testing /api/signal/SPY..."
        curl -v http://localhost:5000/api/signal/SPY || true
        echo ""
    
    - name: Test status endpoint
      run: |
        echo "Testing /api/status..."
        curl -v http://localhost:5000/api/status || true
        echo ""
    
    - name: Generate report
      if: always()
      run: |
        echo "=== Backend Server Test Report ===" > report.txt
        echo "Timestamp: $(date)" >> report.txt
        echo "Server Status: Running" >> report.txt
        echo "" >> report.txt
        echo "=== Test Results ===" >> report.txt
        echo "✓ Health endpoint tested" >> report.txt
        echo "✓ Price endpoint tested (SPY)" >> report.txt
        echo "✓ Historical endpoint tested" >> report.txt
        echo "✓ Signal endpoint tested" >> report.txt
        echo "✓ Status endpoint tested" >> report.txt
        echo "" >> report.txt
        cat report.txt
    
    - name: Upload test report
      if: always()
      uses: actions/upload-artifact@v3
      with:
        name: backend-test-report
        path: report.txt
    
    - name: Upload server logs
      if: always()
      uses: actions/upload-artifact@v3
      with:
        name: server-logs
        path: server.log
    
    - name: Cleanup
      if: always()
      run: |
        # Kill any remaining server processes
        pkill -f "python server.py" || true
        echo "✓ Cleanup completed"

  notify-success:
    runs-on: ubuntu-latest
    needs: run-backend
    if: success()
    steps:
      - name: Success notification
        run: |
          echo "✅ Backend server test completed successfully!"
          echo "All API endpoints are operational."
          echo "Tiingo API key is working correctly."
  
  notify-failure:
    runs-on: ubuntu-latest
    needs: run-backend
    if: failure()
    steps:
      - name: Failure notification
        run: |
          echo "❌ Backend server test failed!"
          echo "Check logs in Actions tab for details."
          echo "Verify TIINGO_API_KEY secret is set correctly."
```

5. **Scroll down and click "Commit new file"**
   - Message: `Add backend server workflow`
   - Select: "Commit directly to the main branch"
   - Click "Commit new file"

### Method B: Via Command Line (Git)

If you're using git locally:

```bash
# In your repo folder, create the file
cat > .github/workflows/backend-server.yml << 'EOF'
[PASTE THE ENTIRE YAML CODE HERE]
EOF

# Commit it
git add .github/workflows/backend-server.yml
git commit -m "Add backend server workflow"
git push origin main
```

---

## STEP 4: Verify Files Exist in GitHub (1 minute)

1. **Go to your repository**
   ```
   https://github.com/aadey002/Stock-agent-
   ```

2. **Look for `.github/workflows/` folder**
   - Click on "Code" tab
   - You should see the `.github` folder
   - Inside it, `workflows` folder
   - Inside that, `backend-server.yml` file

✅ If you see all three → Files are in GitHub!

---

## STEP 5: Watch the Workflow Run (2 minutes)

### First-Time Run

1. **Go to Actions tab**
   ```
   https://github.com/aadey002/Stock-agent-/actions
   ```

2. **Look for "Stock Agent Backend Server" workflow**

3. **Click on it to see the run**

4. **Watch it execute:**
   - ✓ Setup Python
   - ✓ Install dependencies
   - ✓ Start backend server
   - ✓ Test all endpoints
   - ✓ Generate report
   - ✓ Success!

### Expected Output

Green checkmarks ✅ = Success!

```
✅ Setup Python
✅ Install dependencies  
✅ Start backend server
✅ Test health endpoint
✅ Test price endpoint
✅ Test historical endpoint
✅ Test signal endpoint
✅ Test status endpoint
✅ Generate report
```

### If Something Fails

1. **Click on the failed step**
2. **Read the error message**
3. **Common fixes:**
   - "TIINGO_API_KEY not found" → Add it to Secrets (Step 1)
   - "requirements_server.txt not found" → Upload server.py and requirements_server.txt first
   - "ModuleNotFoundError" → Check requirements_server.txt has all dependencies

---

## STEP 6: Ensure Required Files Are Uploaded (5 minutes)

Before running the workflow, make sure these files exist in your repo:

### File 1: `server.py` (Backend Server Code)

1. **Go to: https://github.com/aadey002/Stock-agent-**

2. **Click "Add file" → "Upload files"**

3. **Upload `server.py`**
   - [Download from outputs folder]
   - Or copy-paste the code into a new file

4. **Commit the file**

### File 2: `requirements_server.txt` (Python Dependencies)

1. **Click "Add file" → "Upload files"**

2. **Upload `requirements_server.txt`**
   - [Download from outputs folder]
   - Or create new file with this content:

```
flask==2.3.3
flask-cors==4.0.0
requests==2.31.0
python-dotenv==1.0.0
pandas==2.0.3
numpy==1.24.3
gunicorn==21.2.0
```

3. **Commit the file**

---

## COMPLETE FILE CHECKLIST

✅ Verify all these files exist in your GitHub repository:

```
aadey002/Stock-agent-/
├── .github/
│   └── workflows/
│       └── backend-server.yml          ← WORKFLOW FILE
├── server.py                            ← BACKEND CODE
├── requirements_server.txt              ← DEPENDENCIES
└── [other existing files]
```

---

## 🚀 WHAT HAPPENS AUTOMATICALLY

Once everything is set up:

1. **Workflow triggers on schedule**
   - Every 15 minutes during market hours (9 AM - 4 PM ET, weekdays)

2. **GitHub Actions runs:**
   - Checks out your code
   - Sets up Python environment
   - Installs dependencies
   - Retrieves TIINGO_API_KEY from GitHub Secrets
   - Starts backend server
   - Tests all 5 API endpoints
   - Generates test report
   - Saves logs

3. **You can see results:**
   - Go to Actions tab
   - Click on the workflow
   - View all test results
   - Check logs and artifacts

---

## 🔐 HOW GITHUB SECRETS WORKS

```
Your Tiingo API Key
       ↓
Stored in GitHub Secrets
       ↓
Only accessible in GitHub Actions
       ↓
Workflow uses: ${{ secrets.TIINGO_API_KEY }}
       ↓
Backend server receives it via environment variable
       ↓
API key is NEVER logged or exposed
       ↓
Safe and secure! ✅
```

---

## 📊 MONITORING YOUR WORKFLOW

### View Past Runs
```
https://github.com/aadey002/Stock-agent-/actions
```

### Check Specific Run
1. Click on workflow name
2. Click on run timestamp
3. View logs for each step

### Manual Trigger (Test Anytime)
1. Go to Actions tab
2. Select "Stock Agent Backend Server"
3. Click "Run workflow"
4. Workflow starts immediately

### View Artifacts
1. Click on workflow run
2. Scroll down to "Artifacts"
3. Download logs and reports

---

## ✅ VERIFICATION CHECKLIST

After completing all steps, verify:

- [ ] GitHub Secrets has `TIINGO_API_KEY`
- [ ] `.github/workflows/backend-server.yml` exists
- [ ] `server.py` exists in repository
- [ ] `requirements_server.txt` exists in repository
- [ ] Workflow ran successfully (green checkmark)
- [ ] All tests passed
- [ ] No errors in logs

---

## 🎯 NEXT STEPS

1. **Complete Step 1-6 above**

2. **Watch first workflow run**

3. **Verify all tests pass**

4. **Then update dashboard to use backend:**
   
   In `dashboard_with_backend.html`:
   ```javascript
   // Change this line:
   const API_BASE = 'http://localhost:5000/api';
   
   // To your production backend URL:
   const API_BASE = 'https://your-backend-url.com/api';
   ```

5. **Deploy dashboard to GitHub Pages**

---

## 🆘 TROUBLESHOOTING

### Problem: "No such file or directory: requirements_server.txt"
**Solution:** Upload `requirements_server.txt` to repository root

### Problem: "TIINGO_API_KEY not found"
**Solution:** Add secret to GitHub Secrets (Step 1)

### Problem: "ModuleNotFoundError: No module named 'flask'"
**Solution:** Check requirements_server.txt includes `flask==2.3.3`

### Problem: "Server failed to start"
**Solution:** Check `server.py` is uploaded correctly

### Problem: "curl: command not found"
**Solution:** This is expected on some runners, ignore the error

---

## 📞 QUICK REFERENCE

**GitHub Secrets URL:**
```
https://github.com/aadey002/Stock-agent-/settings/secrets/actions
```

**Actions Tab:**
```
https://github.com/aadey002/Stock-agent-/actions
```

**Repository:**
```
https://github.com/aadey002/Stock-agent-
```

---

**THAT'S IT! You're done! 🎉**

Your backend server is now running on GitHub Actions automatically,
using your Tiingo API key securely from GitHub Secrets.
