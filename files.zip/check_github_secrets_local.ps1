# Run this script locally to check your GitHub secrets
# PowerShell Script to Retrieve GitHub Secrets

param(
    [string]$Owner = "aadey002",
    [string]$Repo = "Stock-agent-",
    [string]$Token = "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"
)

Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║     GitHub Secrets Checker                           ║" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Create headers with GitHub token
$headers = @{
    "Authorization" = "token $Token"
    "Accept" = "application/vnd.github.v3+json"
    "User-Agent" = "PowerShell"
}

Write-Host "Repository: $Owner/$Repo" -ForegroundColor Yellow
Write-Host "Checking for secrets..." -ForegroundColor Yellow
Write-Host ""

try {
    # Get all secrets
    $response = Invoke-WebRequest -Uri "https://api.github.com/repos/$Owner/$Repo/actions/secrets" `
        -Headers $headers `
        -ErrorAction Stop
    
    $secrets = $response.Content | ConvertFrom-Json
    
    if ($secrets.secrets.Count -eq 0) {
        Write-Host "❌ No secrets found!" -ForegroundColor Red
        Write-Host ""
        Write-Host "To add TIINGO_API_KEY secret:" -ForegroundColor Cyan
        Write-Host "1. Go to: https://github.com/$Owner/$Repo/settings/secrets/actions" -ForegroundColor White
        Write-Host "2. Click 'New repository secret'" -ForegroundColor White
        Write-Host "3. Name: TIINGO_API_KEY" -ForegroundColor White
        Write-Host "4. Value: [Your Tiingo API Key]" -ForegroundColor White
        Write-Host "5. Click 'Add secret'" -ForegroundColor White
    } else {
        Write-Host "✅ Found $($secrets.secrets.Count) secret(s):" -ForegroundColor Green
        Write-Host ""
        
        foreach ($secret in $secrets.secrets) {
            Write-Host "Name: $($secret.name)" -ForegroundColor Cyan
            Write-Host "  Last Updated: $($secret.updated_at)" -ForegroundColor Gray
            Write-Host "  Created: $($secret.created_at)" -ForegroundColor Gray
            Write-Host ""
            
            if ($secret.name -eq "TIINGO_API_KEY") {
                Write-Host "  ✅ TIINGO_API_KEY is configured!" -ForegroundColor Green
            }
        }
    }
    
} catch {
    Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "Possible issues:" -ForegroundColor Yellow
    Write-Host "  • GitHub token is invalid or expired" -ForegroundColor White
    Write-Host "  • Repository name is incorrect" -ForegroundColor White
    Write-Host "  • No internet connection" -ForegroundColor White
    Write-Host ""
    Write-Host "Token in use: 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" -ForegroundColor Gray
}

Write-Host ""
Write-Host "╔════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  Manage secrets at:                                  ║" -ForegroundColor Cyan
Write-Host "║  https://github.com/$Owner/$Repo/settings/secrets/actions" -ForegroundColor Cyan
Write-Host "╚════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
